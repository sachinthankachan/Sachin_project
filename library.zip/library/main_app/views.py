from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from datetime import date, timedelta
from .forms import *
from .models import *
from django.contrib.auth import login,authenticate,logout

def index(request):
    return render(request,'index.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('index')
        else:
            print(form.errors)
            messages.error(request, f"Please correct the errors below:")
            messages.error(request, " ".join(
    [f"{field}: {', '.join(errors)}"
     for field, errors in form.errors.items()]
))
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('index')
        else:
            messages.error(request, "Invalid credentials.")
    return render(request, 'login.html')

def user_logout(request):
    logout(request)
    return redirect('index')


# User views
@login_required
def books_list(request):
    books = Book.objects.filter(quantity__gt=0)
    return render(request, 'book_list.html', {'books': books})

@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if book.quantity > 0:
        Borrowing.objects.create(
            user=request.user,
            book=book,
            due_date=date.today() + timedelta(days=14),  # 2 weeks due
        )
        book.quantity -= 1
        book.save()
        messages.success(request, f"You have borrowed '{book.title}' successfully!")
    else:
        messages.error(request, "This book is not available.")
    return redirect('books_list')

@login_required
def my_borrowings(request):
    borrowings = Borrowing.objects.filter(user=request.user).order_by('-borrow_date')
    for borrowing in borrowings:
        if borrowing.status == 'borrowed' and borrowing.due_date < date.today():
            borrowing.status = 'overdue'
            borrowing.save()
    return render(request, 'my_borrowings.html', {'borrowings': borrowings})

@login_required
def return_book(request, borrowing_id):
    borrowing = get_object_or_404(Borrowing, id=borrowing_id, user=request.user)
    if borrowing.status in ['borrowed', 'overdue']:
        borrowing.status = 'pending_return'
        borrowing.return_date = date.today()
        borrowing.save()
        messages.success(request, "Return request submitted. Awaiting admin verification.")
    return redirect('my_borrowings')

# Admin views
@login_required
def admin_dashboard(request):
    if not request.user.is_staff:
        return redirect('index')

    context = {
        'total_books': Book.objects.count(),
        'available_books': Book.objects.filter(quantity__gt=0).count(),
        'total_users': CustomUser.objects.count(),
        'active_borrowings': Borrowing.objects.filter(status='borrowed').count(),
        'overdue_borrowings': Borrowing.objects.filter(status='overdue').count(),
        'returned_books': Borrowing.objects.filter(status='returned').count(),
    }
    return render(request, 'admin_dashboard.html', context)

@login_required
def manage_books(request):
    if not request.user.is_staff:
        return redirect('index')
    books = Book.objects.all()
    return render(request, 'manage_books.html', {'books': books})

@login_required
def add_book(request):
    if not request.user.is_staff:
        return redirect('index')
    if request.method == 'POST':
        form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Book added successfully!")
            return redirect('manage_books')
    else:
        form = BookForm()
    return render(request, 'add_book.html', {'form': form})

@login_required
def edit_book(request, book_id):
    if not request.user.is_staff:
        return redirect('index')
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, "Book updated successfully!")
            return redirect('manage_books')
    else:
        form = BookForm(instance=book)
    return render(request, 'edit_book.html', {'form': form, 'book': book})

@login_required
def delete_book(request, book_id):
    if not request.user.is_staff:
        return redirect('index')
    book = get_object_or_404(Book, id=book_id)
    book.delete()
    messages.success(request, "Book deleted successfully!")
    return redirect('manage_books')

@login_required
def view_borrowings(request):
    if not request.user.is_staff:
        return redirect('index')
    borrowings = Borrowing.objects.all().order_by('-borrow_date')
    return render(request, 'borrowings.html', {'borrowings': borrowings})

@login_required
def verify_return(request, borrowing_id):
    if not request.user.is_staff:
        return redirect('index')
    borrowing = get_object_or_404(Borrowing, id=borrowing_id)
    if borrowing.status == 'pending_return':
        borrowing.status = 'returned'
        borrowing.book.quantity += 1
        borrowing.book.save()
        borrowing.save()
        messages.success(request, "Return verified successfully!")
    return redirect('view_borrowings')