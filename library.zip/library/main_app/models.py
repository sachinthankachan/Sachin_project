from email.policy import default
from django.db import models
from django.contrib.auth.models import AbstractUser
# Create your models here.


class CustomUser(AbstractUser):
    phone = models.CharField(max_length=15, blank=True)
    address = models.TextField(blank=True)

    def __str__(self):
        return self.username

class Book(models.Model):
    GENRES = (
        ('fiction', 'Fiction'),
        ('non_fiction', 'Non-Fiction'),
        ('mystery', 'Mystery'),
        ('sci_fi', 'Sci-Fi'),
        ('biography', 'Biography'),
        ('other', 'Other'),
    )

    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    genre = models.CharField(max_length=20, choices=GENRES, default='other')
    description = models.TextField()
    quantity = models.PositiveIntegerField(default=1)
    added_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} by {self.author}"

class Borrowing(models.Model):
    STATUS_CHOICES = (
        ('borrowed', 'Borrowed'),
        ('returned', 'Returned'),
        ('overdue', 'Overdue'),
        ('pending_return', 'Pending Return Verification'),
    )

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='borrowings')
    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name='borrowings')
    borrow_date = models.DateField(auto_now_add=True)
    due_date = models.DateField()
    return_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='borrowed')

    def __str__(self):
        return f"{self.user.username} borrowed {self.book.title}"