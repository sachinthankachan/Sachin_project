from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Book  # Import both models


# ======================
# Registration Form
# ======================
class RegistrationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = [
            'username', 'phone', 'email', 'password1', 'password2', 'address'
        ]
        widgets = {
            'address': forms.Textarea(attrs={
                'rows': 3,
                'class': 'text-area form-control form-control-lg'
            }),
        }

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if CustomUser.objects.filter(username=username).exists():
            raise forms.ValidationError("Username already exists.")
        return username

    def clean_email(self):
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email=email).exists():
            raise forms.ValidationError("Email already exists.")
        return email

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['username'].help_text = None
        self.fields['email'].help_text = None
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

        for field_name, field in self.fields.items():
            if field_name != 'address':
                field.widget.attrs.update({'class': 'form-control form-control-lg'})
# ======================
# Book Form
# ======================
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'genre', 'description', 'quantity']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Custom labels
        self.fields['title'].label = "Book Title"
        self.fields['author'].label = "Author"
        self.fields['genre'].label = "Genre"
        self.fields['description'].label = "Description"
        self.fields['quantity'].label = "Quantity Available"

        # Apply Bootstrap classes to all fields
        for field_name, field in self.fields.items():
            if field_name != 'description':  # Description has its own widget
                field.widget.attrs.update({'class': 'form-control form-control-lg'})

        # Custom widget for description (larger textarea)
        self.fields['description'].widget = forms.Textarea(attrs={
            'rows': 4,
            'class': 'form-control form-control-lg',
            'style': 'min-height: 120px;'  # Optional: enforce minimum height
        })

        # Genre dropdown
        self.fields['genre'].widget = forms.Select(
            choices=Book.GENRES,
            attrs={'class': 'form-select form-select-lg'}
        )