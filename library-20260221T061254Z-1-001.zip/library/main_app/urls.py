from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),

    path('book-list/', views.books_list, name='books_list'),
    path('borrow/<int:book_id>/', views.borrow_book, name='borrow_book'),
    path('my-borrowings/', views.my_borrowings, name='my_borrowings'),
    path('return/<int:borrowing_id>/', views.return_book, name='return_book'),

    # Admin
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-manage-books/', views.manage_books, name='manage_books'),
    path('admin-add-book/', views.add_book, name='add_book'),
    path('admin-edit-book/<int:book_id>/', views.edit_book, name='edit_book'),
    path('admin-delete-book/<int:book_id>/', views.delete_book, name='delete_book'),
    path('admin-borrowings/', views.view_borrowings, name='view_borrowings'),
    path('admin-verify-return/<int:borrowing_id>/', views.verify_return, name='verify_return'),

]